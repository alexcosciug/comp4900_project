#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define NUMTHREADS      5
void* printThreadDetails();
const struct sched_param *param;
pthread_attr_t attr[NUMTHREADS];
pthread_t thread[NUMTHREADS];

int main(int argc, char *argv[]) {

	for(int i = 0; i < NUMTHREADS; ++i){
		pthread_attr_init (&attr[i]);
		pthread_create(&thread[i], &attr[i], &printThreadDetails, NULL );
		pthread_setschedparam(thread[i],SCHED_RR,param);
		pthread_setschedprio(thread[i], 5+i);
	}
	for (int i = 0; i < NUMTHREADS; i++){
	       pthread_join(thread[i], NULL);
	       pthread_attr_destroy(&attr[i]);
	}
	return EXIT_SUCCESS;
}

void* printThreadDetails() {
	pthread_t	tid;
	struct sched_param params;
	sleep(20);
	pthread_getschedparam (pthread_self(), NULL, &params);
	tid = pthread_self();
	printf("thread id = %d thread priority = %d\n", tid, params.sched_priority);
	return(0);
}

